package com.udb.bancoagricultura.bancodeagriculturasalvadoreno.service;

import com.udb.bancoagricultura.bancodeagriculturasalvadoreno.model.pojo.CuentaBancaria;
import com.udb.bancoagricultura.bancodeagriculturasalvadoreno.model.pojo.Prestamo;
import com.udb.bancoagricultura.bancodeagriculturasalvadoreno.model.pojo.Usuario;
import com.udb.bancoagricultura.bancodeagriculturasalvadoreno.model.util.JPAUtil;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.List;

public class PrestamoService {

    public Prestamo buscarPorId(Long id) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return em.find(Prestamo.class, id);
        } finally {
            em.close();
        }
    }

    public List<Prestamo> listarTodos() {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            TypedQuery<Prestamo> query = em.createQuery(
                    "SELECT p FROM Prestamo p ORDER BY p.fechaDesembolso DESC",
                    Prestamo.class
            );
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Prestamo> obtenerPrestamosPorCuenta(CuentaBancaria cuenta) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            TypedQuery<Prestamo> query = em.createQuery(
                    "SELECT p FROM Prestamo p WHERE p.cuenta = :cuenta ORDER BY p.fechaDesembolso DESC",
                    Prestamo.class
            );
            query.setParameter("cuenta", cuenta);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public List<Prestamo> obtenerPrestamosPorCliente(Usuario cliente) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            TypedQuery<Prestamo> query = em.createQuery(
                    "SELECT p FROM Prestamo p " +
                            "WHERE p.cuenta.cliente = :cliente " +
                            "ORDER BY p.fechaDesembolso DESC",
                    Prestamo.class
            );
            query.setParameter("cliente", cliente);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public void guardar(Prestamo prestamo) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            em.getTransaction().begin();

            if (prestamo.getIdPrestamo() == null) {
                em.persist(prestamo);
            } else {
                em.merge(prestamo);
            }

            em.getTransaction().commit();
        } catch (Exception ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw ex;
        } finally {
            em.close();
        }
    }
}
