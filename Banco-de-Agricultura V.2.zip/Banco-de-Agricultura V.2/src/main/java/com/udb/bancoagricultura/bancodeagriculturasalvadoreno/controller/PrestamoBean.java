package com.udb.bancoagricultura.bancodeagriculturasalvadoreno.controller;

import com.udb.bancoagricultura.bancodeagriculturasalvadoreno.model.pojo.Prestamo;
import com.udb.bancoagricultura.bancodeagriculturasalvadoreno.model.pojo.Usuario;
import com.udb.bancoagricultura.bancodeagriculturasalvadoreno.service.PrestamoService;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Named("prestamosBean")
@SessionScoped
public class PrestamoBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private Prestamo prestamoNuevo;
    private Prestamo prestamoSeleccionado;

    private List<Prestamo> prestamosCliente;

    @Inject
    private LoginBean loginBean;

    private PrestamoService prestamoService;

    @PostConstruct
    public void init() {
        prestamoNuevo = new Prestamo();
        prestamosCliente = new ArrayList<>();
        prestamoService = new PrestamoService();
        cargarPrestamosCliente();
    }

    public void cargarPrestamosCliente() {
        try {
            Usuario usuario = loginBean.getUsuarioLogeado();
            if (usuario != null) {
                prestamosCliente = prestamoService.obtenerPrestamosPorCliente(usuario);
            } else {
                prestamosCliente = new ArrayList<>();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error al cargar préstamos",
                            ex.getMessage()));
        }
    }

    public void prepararNuevoPrestamo() {
        prestamoNuevo = new Prestamo();
        prestamoNuevo.setFechaDesembolso(new Date());
        prestamoNuevo.setEstado("PENDIENTE");

        // Como NO usas BigDecimal, se reemplaza por Double
        prestamoNuevo.setMonto(0.0);
        prestamoNuevo.setTasaInteres(0.0);
        prestamoNuevo.setPlazoMeses(12);
    }

    public void guardarPrestamo() {
        try {
            prestamoService.guardar(prestamoNuevo);

            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO,
                            "Préstamo guardado",
                            "El préstamo ha sido registrado correctamente."));

            cargarPrestamosCliente();
            prestamoNuevo = new Prestamo();

        } catch (Exception ex) {
            ex.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Error al guardar el préstamo",
                            ex.getMessage()));
        }
    }

    // Getters y setters

    public Prestamo getPrestamoNuevo() {
        return prestamoNuevo;
    }

    public void setPrestamoNuevo(Prestamo prestamoNuevo) {
        this.prestamoNuevo = prestamoNuevo;
    }

    public Prestamo getPrestamoSeleccionado() {
        return prestamoSeleccionado;
    }

    public void setPrestamoSeleccionado(Prestamo prestamoSeleccionado) {
        this.prestamoSeleccionado = prestamoSeleccionado;
    }

    public List<Prestamo> getPrestamosCliente() {
        return prestamosCliente;
    }

    public void setPrestamosCliente(List<Prestamo> prestamosCliente) {
        this.prestamosCliente = prestamosCliente;
    }
}
